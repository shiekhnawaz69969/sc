package Shapes;

public interface Shape {
    public void draw();
}
