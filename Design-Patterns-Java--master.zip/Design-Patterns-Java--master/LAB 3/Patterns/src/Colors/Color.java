package Colors;


public interface Color {
    public void fill();
}
