Common Design Patterns implemented in Java!
