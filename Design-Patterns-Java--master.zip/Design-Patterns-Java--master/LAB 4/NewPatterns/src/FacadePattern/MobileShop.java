package FacadePattern;


public interface MobileShop {
    public void ModelNo();
    public void Price();
}
