package BuilderPattern;


public abstract class Company extends CD{  
   @Override
   public abstract int price();  
}  
