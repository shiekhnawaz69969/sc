package AdapterPattern;

public class Lamburgini implements Moveable{

    @Override
    public double speed() {
        return 285;
    }
}
