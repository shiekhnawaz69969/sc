package AdapterPattern;

public interface MoveableAdapter{
    public double speed();
}
