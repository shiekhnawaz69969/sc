package AdapterPattern;

public interface Moveable{
    public double speed();
}
